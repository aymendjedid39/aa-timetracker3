# A&A Employee Time Tracker — PWA

A fully offline-capable Progressive Web App installable on Android, iPhone, and desktop computers.

---

## 📁 Files in this package

```
aa-timetracker-pwa/
├── index.html       ← The app (your original + PWA enhancements)
├── manifest.json    ← Makes it installable as an app
├── sw.js            ← Service Worker (offline support)
├── icons/
│   ├── icon-192.png ← App icon (Android / desktop)
│   └── icon-512.png ← App icon (splash screen)
└── README.md        ← This file
```

---

## 🚀 Deploy to GitHub Pages (Step-by-Step)

### Step 1 — Create a GitHub account
Go to https://github.com and sign up for a free account if you don't have one.

### Step 2 — Create a new repository
1. Click the **+** button (top right) → **New repository**
2. Name it: `aa-timetracker` (or any name you like)
3. Set it to **Public**
4. ✅ Check **"Add a README file"**
5. Click **Create repository**

### Step 3 — Upload the files
1. Inside your new repository, click **Add file** → **Upload files**
2. Drag and drop ALL files from this folder:
   - `index.html`
   - `manifest.json`
   - `sw.js`
3. Click **Commit changes**

### Step 4 — Upload the icons folder
1. Click **Add file** → **Upload files** again
2. Open the `icons/` folder on your computer
3. Drag both `icon-192.png` and `icon-512.png` into the upload area
4. In the destination path box type: `icons/`
5. Click **Commit changes**

   > **Tip:** GitHub needs the icons inside a folder named `icons`. Make sure the path shown is `icons/icon-192.png`, not just `icon-192.png`.

### Step 5 — Enable GitHub Pages
1. In your repository, go to **Settings** (top menu)
2. Scroll down to **Pages** (left sidebar)
3. Under **Source**, select **Deploy from a branch**
4. Choose branch: **main** · Folder: **/ (root)**
5. Click **Save**

### Step 6 — Get your app URL
After 1–2 minutes, GitHub Pages will show your URL at the top of the Pages settings:

```
https://YOUR-USERNAME.github.io/aa-timetracker/
```

Open this URL on any device — that's your app! 🎉

---

## 📲 Installing the App

### Android (Chrome)
1. Open the app URL in Chrome
2. Tap the **⋮** menu (top right)
3. Tap **"Add to Home Screen"** or **"Install app"**
4. Confirm — it now appears on your home screen like a native app

### iPhone / iPad (Safari)
1. Open the app URL in **Safari** (must be Safari, not Chrome)
2. Tap the **Share** button (square with arrow at bottom)
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **Add** — done!

### Desktop (Chrome / Edge)
1. Open the URL in Chrome or Edge
2. Look for the **install icon** (⊕) in the address bar
3. Click it → **Install**
4. The app opens in its own window, no browser chrome

---

## ✈️ Offline Use

The app works **100% offline** after the first visit:

- All employee data, sessions, and logs are stored in the **browser's localStorage** on the device
- The Service Worker caches the app shell AND all CDN fonts/libraries on first load
- After that, you can disable Wi-Fi and the app still works fully

> **Note:** Data is per-device. If you need data shared across multiple devices/computers at the same workplace, you would need a backend database (not included in this version).

---

## 🔄 Updating the App

When you upload a new `index.html` to GitHub:
1. GitHub Pages updates automatically within ~1 minute
2. Users will get the new version the next time they open the app while online
3. The Service Worker version (`CACHE_NAME = 'aa-timetracker-v1'`) can be bumped in `sw.js` to force a cache refresh

---

## 🛡️ Data & Privacy

- All data stays **on the device** in localStorage
- Nothing is sent to any server
- GitHub only hosts the static app files (HTML/JS/CSS)
